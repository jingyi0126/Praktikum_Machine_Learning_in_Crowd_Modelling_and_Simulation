Corridor data are trajectories of pedestrians in a closed corridor of lenght 30m and width 1.8m. 
The trajectories are measured on a section of length 6m. 
Experiments are carried out with N=15, 30, 60, 85, 95, 110, 140 and 230 participants. 

Bottleneck data are trajectories of pedestrian in a bottleneck of lenght 8m and width 1.8m. 
Experiments are carried out with 150 participants for bottleneck widths w=0.7, 0.95 1.2 and 1.8m. 

See http://ped.fz-juelich.de/experiments/2009.05.12_Duesseldorf_Messe_Hermes/docu/VersuchsdokumentationHERMES.pdf page 20 and 28 for details. Column names of the file are: ID FRAME X Y Z. ID is the pedestrian ID. FRAME is the frame number (frame rate is 1/16s). X Y and Z pedestrian position in 3D. The data are part of the online database http://ped.fz-juelich.de/database.

Column names of the file are: ID FRAME X Y Z. 
ID is the pedestrian ID. 
FRAME is the frame number (frame rate is 1/16s). 
X Y and Z pedestrian position in 3D. 